
  # Healthcare Web App UI Design

  This is a code bundle for Healthcare Web App UI Design. The original project is available at https://www.figma.com/design/mIkItti7YfKxtgmVyI91qH/Healthcare-Web-App-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  