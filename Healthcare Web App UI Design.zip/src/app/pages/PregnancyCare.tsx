import { Baby, Apple, Dumbbell, AlertCircle } from "lucide-react";

const symptoms = [
  { id: 1, symptom: "Nausea & Morning Sickness", description: "Common in first trimester, usually improves after 12 weeks" },
  { id: 2, symptom: "Fatigue", description: "Increased tiredness, especially in first and third trimesters" },
  { id: 3, symptom: "Frequent Urination", description: "Pressure on bladder increases throughout pregnancy" },
  { id: 4, symptom: "Back Pain", description: "Lower back pain due to weight gain and posture changes" },
  { id: 5, symptom: "Swollen Feet", description: "Fluid retention, especially in later stages" },
  { id: 6, symptom: "Heartburn", description: "Digestive changes can cause acid reflux" },
];

const foodList = {
  recommended: [
    "Leafy greens (spinach, kale)",
    "Lean proteins (chicken, fish)",
    "Whole grains (brown rice, quinoa)",
    "Dairy products (milk, yogurt)",
    "Fruits (berries, oranges, bananas)",
    "Legumes (lentils, beans)",
    "Nuts and seeds",
    "Sweet potatoes",
  ],
  avoid: [
    "Raw or undercooked meat",
    "Unpasteurized dairy",
    "High-mercury fish (shark, swordfish)",
    "Raw eggs",
    "Excessive caffeine",
    "Alcohol",
    "Unwashed produce",
    "Processed junk food",
  ],
};

const exercises = [
  { name: "Walking", duration: "30 mins daily", benefit: "Improves cardiovascular health and stamina" },
  { name: "Swimming", duration: "20-30 mins", benefit: "Low-impact full body workout, reduces swelling" },
  { name: "Prenatal Yoga", duration: "15-30 mins", benefit: "Increases flexibility, reduces stress" },
  { name: "Kegel Exercises", duration: "10 mins daily", benefit: "Strengthens pelvic floor muscles" },
  { name: "Pelvic Tilts", duration: "5-10 mins", benefit: "Relieves back pain, strengthens core" },
  { name: "Squats", duration: "5-10 reps", benefit: "Prepares body for labor, strengthens legs" },
];

export function PregnancyCare() {
  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-pink-500 to-rose-500 rounded-lg p-8 text-white">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center">
            <Baby className="w-8 h-8" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Pregnancy Care</h1>
            <p className="text-pink-100 mt-1">Comprehensive guide for a healthy pregnancy and normal delivery</p>
          </div>
        </div>
      </div>

      {/* Common Symptoms */}
      <section className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
        <h2 className="text-2xl font-semibold text-slate-800 mb-4 flex items-center gap-2">
          <AlertCircle className="w-6 h-6 text-rose-500" />
          Common Pregnancy Symptoms
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {symptoms.map((item) => (
            <div key={item.id} className="p-4 bg-rose-50 rounded-lg border border-rose-100">
              <h3 className="font-semibold text-slate-800 mb-1">{item.symptom}</h3>
              <p className="text-sm text-slate-600">{item.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Food Recommendations */}
      <section className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
        <h2 className="text-2xl font-semibold text-slate-800 mb-4 flex items-center gap-2">
          <Apple className="w-6 h-6 text-green-500" />
          Food Recommendations
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Recommended Foods */}
          <div>
            <h3 className="font-semibold text-green-700 mb-3 text-lg">✓ Recommended Foods</h3>
            <ul className="space-y-2">
              {foodList.recommended.map((food, index) => (
                <li key={index} className="flex items-start gap-2 text-slate-700">
                  <span className="text-green-500 mt-0.5">•</span>
                  <span>{food}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Foods to Avoid */}
          <div>
            <h3 className="font-semibold text-red-700 mb-3 text-lg">✗ Foods to Avoid</h3>
            <ul className="space-y-2">
              {foodList.avoid.map((food, index) => (
                <li key={index} className="flex items-start gap-2 text-slate-700">
                  <span className="text-red-500 mt-0.5">•</span>
                  <span>{food}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Exercise Tips */}
      <section className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
        <h2 className="text-2xl font-semibold text-slate-800 mb-4 flex items-center gap-2">
          <Dumbbell className="w-6 h-6 text-blue-500" />
          Exercise Tips for Normal Delivery
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {exercises.map((exercise, index) => (
            <div key={index} className="p-4 bg-blue-50 rounded-lg border border-blue-100">
              <h3 className="font-semibold text-slate-800 mb-1">{exercise.name}</h3>
              <p className="text-sm text-blue-700 mb-2">{exercise.duration}</p>
              <p className="text-sm text-slate-600">{exercise.benefit}</p>
            </div>
          ))}
        </div>
        <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
          <p className="text-amber-900 text-sm">
            <strong>Important:</strong> Always consult with your healthcare provider before starting any exercise routine during pregnancy.
          </p>
        </div>
      </section>
    </div>
  );
}
