import { useState } from "react";
import { Calendar, Search, Star, Clock, Zap, Filter } from "lucide-react";

interface Doctor {
  id: number;
  name: string;
  specialization: string;
  rating: number;
  experience: string;
  availability: string;
  image: string;
}

const doctors: Doctor[] = [
  { id: 1, name: "Dr. Sarah Johnson", specialization: "Cardiology", rating: 4.8, experience: "15 years", availability: "Today, 2:00 PM", image: "👨‍⚕️" },
  { id: 2, name: "Dr. Michael Chen", specialization: "Pediatrics", rating: 4.9, experience: "12 years", availability: "Tomorrow, 10:00 AM", image: "👩‍⚕️" },
  { id: 3, name: "Dr. Emily Brown", specialization: "Dermatology", rating: 4.7, experience: "10 years", availability: "Today, 4:30 PM", image: "👨‍⚕️" },
  { id: 4, name: "Dr. James Wilson", specialization: "Orthopedics", rating: 4.9, experience: "18 years", availability: "Tomorrow, 11:30 AM", image: "👩‍⚕️" },
  { id: 5, name: "Dr. Lisa Martinez", specialization: "General Medicine", rating: 4.6, experience: "8 years", availability: "Today, 3:00 PM", image: "👨‍⚕️" },
  { id: 6, name: "Dr. David Lee", specialization: "Gynecology", rating: 4.8, experience: "14 years", availability: "Tomorrow, 9:00 AM", image: "👩‍⚕️" },
];

const specializations = ["All", "Cardiology", "Pediatrics", "Dermatology", "Orthopedics", "General Medicine", "Gynecology"];

export function DoctorAppointment() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedSpecialization, setSelectedSpecialization] = useState("All");
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [bookingConfirmed, setBookingConfirmed] = useState(false);

  const filteredDoctors = doctors.filter((doctor) => {
    const matchesSearch = doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doctor.specialization.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSpecialization = selectedSpecialization === "All" || doctor.specialization === selectedSpecialization;
    return matchesSearch && matchesSpecialization;
  });

  const handleBookAppointment = (doctor: Doctor, isUrgent: boolean = false) => {
    setSelectedDoctor(doctor);
    setBookingConfirmed(true);
    setTimeout(() => setBookingConfirmed(false), 3000);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-500 to-cyan-500 rounded-lg p-8 text-white">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center">
            <Calendar className="w-8 h-8" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Doctor Appointment</h1>
            <p className="text-blue-100 mt-1">Book appointments with qualified healthcare professionals</p>
          </div>
        </div>
      </div>

      {/* Search and Filter */}
      <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by doctor name or specialization..."
              className="w-full pl-10 pr-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
            />
          </div>

          {/* Filter by Specialization */}
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <select
              value={selectedSpecialization}
              onChange={(e) => setSelectedSpecialization(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none bg-white appearance-none"
            >
              {specializations.map((spec) => (
                <option key={spec} value={spec}>
                  {spec === "All" ? "All Specializations" : spec}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Confirmation Message */}
      {bookingConfirmed && selectedDoctor && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 animate-in fade-in">
          <p className="text-green-800 text-center font-medium">
            ✓ Appointment booked with {selectedDoctor.name} - {selectedDoctor.availability}
          </p>
        </div>
      )}

      {/* Doctors List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredDoctors.map((doctor) => (
          <div key={doctor.id} className="bg-white rounded-lg shadow-sm border border-slate-200 p-5 hover:shadow-md transition-shadow">
            <div className="flex items-start gap-3 mb-4">
              <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center text-3xl">
                {doctor.image}
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-slate-800">{doctor.name}</h3>
                <p className="text-sm text-slate-600">{doctor.specialization}</p>
                <div className="flex items-center gap-1 mt-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span className="text-sm font-medium">{doctor.rating}</span>
                  <span className="text-xs text-slate-500">({doctor.experience})</span>
                </div>
              </div>
            </div>

            <div className="space-y-2 mb-4">
              <div className="flex items-center gap-2 text-sm text-slate-600">
                <Clock className="w-4 h-4" />
                <span>{doctor.availability}</span>
              </div>
            </div>

            <div className="space-y-2">
              <button
                onClick={() => handleBookAppointment(doctor, false)}
                className="w-full py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
              >
                Book Appointment
              </button>
              <button
                onClick={() => handleBookAppointment(doctor, true)}
                className="w-full py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors text-sm font-medium flex items-center justify-center gap-2"
              >
                <Zap className="w-4 h-4" />
                Urgent → Premium
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredDoctors.length === 0 && (
        <div className="text-center py-12 bg-white rounded-lg border border-slate-200">
          <Calendar className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <p className="text-slate-500">No doctors found matching your criteria</p>
          <p className="text-sm text-slate-400 mt-1">Try adjusting your search or filters</p>
        </div>
      )}

      {/* Premium Service Info */}
      <div className="bg-gradient-to-br from-red-50 to-orange-50 rounded-lg p-6 border border-red-100">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-full bg-red-500 flex items-center justify-center flex-shrink-0">
            <Zap className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-slate-800 mb-2">Urgent Premium Service</h3>
            <p className="text-sm text-slate-700 mb-2">
              Need immediate medical attention? Our premium urgent service offers:
            </p>
            <ul className="text-sm text-slate-700 space-y-1">
              <li>• Priority appointment within 2 hours</li>
              <li>• Video consultation available</li>
              <li>• 24/7 support access</li>
              <li>• Emergency contact with specialists</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
