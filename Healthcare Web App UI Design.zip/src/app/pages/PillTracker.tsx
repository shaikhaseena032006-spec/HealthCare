import { useState } from "react";
import { Pill, Clock, Plus, Trash2, Bell } from "lucide-react";

interface Medicine {
  id: string;
  name: string;
  time: string;
  frequency: string;
}

export function PillTracker() {
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [newMedicine, setNewMedicine] = useState({
    name: "",
    time: "",
    frequency: "Once daily",
  });

  const handleAddMedicine = (e: React.FormEvent) => {
    e.preventDefault();
    const medicine: Medicine = {
      id: Date.now().toString(),
      ...newMedicine,
    };
    setMedicines([...medicines, medicine]);
    setNewMedicine({ name: "", time: "", frequency: "Once daily" });
  };

  const handleDelete = (id: string) => {
    setMedicines(medicines.filter((med) => med.id !== id));
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-500 to-purple-500 rounded-lg p-8 text-white">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center">
            <Pill className="w-8 h-8" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Pill Tracker</h1>
            <p className="text-indigo-100 mt-1">Never miss your medication with reminders</p>
          </div>
        </div>
      </div>

      {/* Add Medicine Form */}
      <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
        <h2 className="text-xl font-semibold text-slate-800 mb-4 flex items-center gap-2">
          <Plus className="w-5 h-5 text-indigo-600" />
          Add New Medicine
        </h2>
        <form onSubmit={handleAddMedicine} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Medicine Name</label>
              <input
                type="text"
                value={newMedicine.name}
                onChange={(e) => setNewMedicine({ ...newMedicine, name: e.target.value })}
                required
                className="w-full px-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
                placeholder="e.g., Vitamin D"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                <Clock className="inline w-4 h-4 mr-1" />
                Time
              </label>
              <input
                type="time"
                value={newMedicine.time}
                onChange={(e) => setNewMedicine({ ...newMedicine, time: e.target.value })}
                required
                className="w-full px-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Frequency</label>
              <select
                value={newMedicine.frequency}
                onChange={(e) => setNewMedicine({ ...newMedicine, frequency: e.target.value })}
                className="w-full px-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none bg-white"
              >
                <option>Once daily</option>
                <option>Twice daily</option>
                <option>Three times daily</option>
                <option>Every 6 hours</option>
                <option>Every 8 hours</option>
                <option>As needed</option>
              </select>
            </div>
          </div>
          <button
            type="submit"
            className="w-full md:w-auto px-6 py-2.5 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors font-medium"
          >
            Add Medicine
          </button>
        </form>
      </div>

      {/* Medicine List */}
      <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
        <h2 className="text-xl font-semibold text-slate-800 mb-4 flex items-center gap-2">
          <Bell className="w-5 h-5 text-indigo-600" />
          Your Reminders
        </h2>

        {medicines.length === 0 ? (
          <div className="text-center py-12">
            <Pill className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-500">No medicines added yet</p>
            <p className="text-sm text-slate-400 mt-1">Add your first medicine to get started</p>
          </div>
        ) : (
          <div className="space-y-3">
            {medicines.map((medicine) => (
              <div
                key={medicine.id}
                className="flex items-center justify-between p-4 bg-indigo-50 rounded-lg border border-indigo-100 hover:border-indigo-200 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-indigo-100 flex items-center justify-center">
                    <Pill className="w-6 h-6 text-indigo-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-800">{medicine.name}</h3>
                    <p className="text-sm text-slate-600">
                      <Clock className="inline w-3.5 h-3.5 mr-1" />
                      {medicine.time} • {medicine.frequency}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => handleDelete(medicine.id)}
                  className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                  aria-label="Delete medicine"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Tips */}
      <div className="bg-gradient-to-br from-purple-50 to-indigo-50 rounded-lg p-6 border border-purple-100">
        <h3 className="font-semibold text-slate-800 mb-3">💡 Tips for Better Medicine Management</h3>
        <ul className="space-y-2 text-sm text-slate-700">
          <li>• Set phone alarms for each medicine reminder</li>
          <li>• Keep medicines in a visible location</li>
          <li>• Take medicines with food if recommended</li>
          <li>• Never skip doses without consulting your doctor</li>
          <li>• Check expiration dates regularly</li>
        </ul>
      </div>
    </div>
  );
}
