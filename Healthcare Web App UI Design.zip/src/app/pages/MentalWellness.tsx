import { useState } from "react";
import { Heart, Brain, Music, Wind } from "lucide-react";

const questions = [
  { id: 1, question: "How often do you feel stressed or anxious?", max: 5 },
  { id: 2, question: "How well are you sleeping at night?", max: 5 },
  { id: 3, question: "How often do you feel overwhelmed by daily tasks?", max: 5 },
  { id: 4, question: "How satisfied are you with your social connections?", max: 5 },
  { id: 5, question: "How often do you engage in activities you enjoy?", max: 5 },
  { id: 6, question: "How would you rate your energy levels throughout the day?", max: 5 },
  { id: 7, question: "How often do you feel hopeful about the future?", max: 5 },
];

export function MentalWellness() {
  const [answers, setAnswers] = useState<{ [key: number]: number }>({});
  const [result, setResult] = useState<{ score: number; level: string; color: string } | null>(null);

  const handleAnswer = (questionId: number, value: number) => {
    setAnswers({
      ...answers,
      [questionId]: value,
    });
    setResult(null);
  };

  const calculateScore = () => {
    const totalAnswered = Object.keys(answers).length;
    if (totalAnswered < questions.length) {
      alert("Please answer all questions");
      return;
    }

    const totalScore = Object.values(answers).reduce((sum, val) => sum + val, 0);
    const maxScore = questions.length * 5;
    const percentage = (totalScore / maxScore) * 100;

    let level = "";
    let color = "";

    if (percentage >= 70) {
      level = "High";
      color = "green";
    } else if (percentage >= 40) {
      level = "Medium";
      color = "yellow";
    } else {
      level = "Low";
      color = "red";
    }

    setResult({ score: Math.round(percentage), level, color });
  };

  const getColorClasses = (color: string) => {
    switch (color) {
      case "green":
        return { bg: "bg-green-50", border: "border-green-200", text: "text-green-800", badge: "bg-green-500" };
      case "yellow":
        return { bg: "bg-yellow-50", border: "border-yellow-200", text: "text-yellow-800", badge: "bg-yellow-500" };
      case "red":
        return { bg: "bg-red-50", border: "border-red-200", text: "text-red-800", badge: "bg-red-500" };
      default:
        return { bg: "bg-slate-50", border: "border-slate-200", text: "text-slate-800", badge: "bg-slate-500" };
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg p-8 text-white">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center">
            <Heart className="w-8 h-8" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Mental Wellness Check</h1>
            <p className="text-purple-100 mt-1">Assess your mental health and get personalized recommendations</p>
          </div>
        </div>
      </div>

      {/* Questionnaire */}
      <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
        <h2 className="text-xl font-semibold text-slate-800 mb-4 flex items-center gap-2">
          <Brain className="w-5 h-5 text-purple-600" />
          Mental Health Assessment
        </h2>
        <p className="text-sm text-slate-600 mb-6">
          Rate each question from 1 (Poor) to 5 (Excellent)
        </p>

        <div className="space-y-6">
          {questions.map((q) => (
            <div key={q.id} className="pb-6 border-b border-slate-100 last:border-0">
              <p className="text-slate-700 mb-3 font-medium">
                {q.id}. {q.question}
              </p>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map((value) => (
                  <button
                    key={value}
                    onClick={() => handleAnswer(q.id, value)}
                    className={`flex-1 py-2 px-3 rounded-lg border-2 transition-all ${
                      answers[q.id] === value
                        ? "border-purple-500 bg-purple-50 text-purple-700 font-semibold"
                        : "border-slate-200 hover:border-purple-300 text-slate-600"
                    }`}
                  >
                    {value}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>

        <button
          onClick={calculateScore}
          className="w-full mt-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors font-medium"
        >
          Calculate Wellness Score
        </button>
      </div>

      {/* Results */}
      {result && (
        <div className={`rounded-lg shadow-sm border p-6 ${getColorClasses(result.color).bg} ${getColorClasses(result.color).border}`}>
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Heart className="w-6 h-6" />
            Your Wellness Score
          </h2>
          <div className="flex items-center gap-4 mb-6">
            <div className="text-5xl font-bold">{result.score}%</div>
            <div>
              <div className={`inline-block px-4 py-1 rounded-full text-white font-semibold ${getColorClasses(result.color).badge}`}>
                {result.level} Wellness
              </div>
            </div>
          </div>

          {/* Recommendations */}
          <div className="space-y-4">
            <h3 className="font-semibold text-lg">Recommended Activities</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white rounded-lg p-4 border border-slate-200">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                    <Music className="w-5 h-5 text-blue-600" />
                  </div>
                  <h4 className="font-semibold text-slate-800">Calm Music Therapy</h4>
                </div>
                <p className="text-sm text-slate-600">
                  Listen to relaxing music for 15-20 minutes daily. Try instrumental, nature sounds, or meditation music.
                </p>
              </div>

              <div className="bg-white rounded-lg p-4 border border-slate-200">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-full bg-teal-100 flex items-center justify-center">
                    <Wind className="w-5 h-5 text-teal-600" />
                  </div>
                  <h4 className="font-semibold text-slate-800">Breathing Exercises</h4>
                </div>
                <p className="text-sm text-slate-600">
                  Practice deep breathing: Inhale for 4 counts, hold for 4, exhale for 6. Repeat 10 times, twice daily.
                </p>
              </div>
            </div>

            {result.level === "Low" && (
              <div className="mt-4 p-4 bg-amber-50 border border-amber-200 rounded-lg">
                <p className="text-amber-900 text-sm">
                  <strong>Important:</strong> Consider speaking with a mental health professional for personalized support and guidance.
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* General Tips */}
      <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg p-6 border border-purple-100">
        <h3 className="font-semibold text-slate-800 mb-3">💜 Daily Mental Wellness Tips</h3>
        <ul className="space-y-2 text-sm text-slate-700">
          <li>• Practice gratitude by writing 3 things you're thankful for each day</li>
          <li>• Get 7-9 hours of quality sleep each night</li>
          <li>• Engage in physical activity for at least 30 minutes daily</li>
          <li>• Connect with friends and family regularly</li>
          <li>• Limit screen time, especially before bed</li>
          <li>• Take breaks throughout the day to relax and recharge</li>
        </ul>
      </div>
    </div>
  );
}
