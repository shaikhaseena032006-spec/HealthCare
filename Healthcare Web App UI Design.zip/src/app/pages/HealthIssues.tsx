import { useState } from "react";
import { Activity, AlertCircle, Users } from "lucide-react";

interface HealthIssue {
  name: string;
  symptoms: string[];
  whenToConsult: string;
}

const healthIssuesByAge: { [key: string]: HealthIssue[] } = {
  "0-12": [
    {
      name: "Common Cold",
      symptoms: ["Runny nose", "Cough", "Mild fever", "Sneezing"],
      whenToConsult: "If fever persists for more than 3 days or breathing difficulties occur",
    },
    {
      name: "Ear Infections",
      symptoms: ["Ear pain", "Pulling at ears", "Fever", "Irritability"],
      whenToConsult: "If pain is severe or child has high fever",
    },
    {
      name: "Stomach Flu",
      symptoms: ["Vomiting", "Diarrhea", "Stomach cramps", "Fever"],
      whenToConsult: "If signs of dehydration appear or symptoms last more than 48 hours",
    },
  ],
  "13-25": [
    {
      name: "Acne",
      symptoms: ["Pimples", "Blackheads", "Oily skin", "Scarring"],
      whenToConsult: "If acne is severe, painful, or causing emotional distress",
    },
    {
      name: "Anxiety & Stress",
      symptoms: ["Excessive worry", "Restlessness", "Difficulty concentrating", "Sleep problems"],
      whenToConsult: "If symptoms interfere with daily life or last more than 2 weeks",
    },
    {
      name: "Sports Injuries",
      symptoms: ["Pain", "Swelling", "Limited mobility", "Bruising"],
      whenToConsult: "If unable to bear weight or severe pain persists",
    },
  ],
  "26-45": [
    {
      name: "Back Pain",
      symptoms: ["Lower back ache", "Stiffness", "Muscle spasms", "Limited movement"],
      whenToConsult: "If pain radiates down legs, numbness occurs, or pain is severe",
    },
    {
      name: "High Blood Pressure",
      symptoms: ["Headaches", "Dizziness", "Chest pain", "Often asymptomatic"],
      whenToConsult: "Regular monitoring recommended; consult if readings consistently above 140/90",
    },
    {
      name: "Migraines",
      symptoms: ["Severe headache", "Nausea", "Sensitivity to light", "Visual disturbances"],
      whenToConsult: "If migraines are frequent, severe, or accompanied by neurological symptoms",
    },
  ],
  "46-60": [
    {
      name: "Diabetes",
      symptoms: ["Increased thirst", "Frequent urination", "Fatigue", "Blurred vision"],
      whenToConsult: "If experiencing multiple symptoms or blood sugar levels are abnormal",
    },
    {
      name: "Heart Disease",
      symptoms: ["Chest pain", "Shortness of breath", "Fatigue", "Irregular heartbeat"],
      whenToConsult: "Seek immediate medical attention for chest pain or severe symptoms",
    },
    {
      name: "Arthritis",
      symptoms: ["Joint pain", "Stiffness", "Swelling", "Reduced range of motion"],
      whenToConsult: "If joint pain persists for more than 2 weeks or limits daily activities",
    },
  ],
  "60+": [
    {
      name: "Osteoporosis",
      symptoms: ["Bone fractures", "Loss of height", "Stooped posture", "Back pain"],
      whenToConsult: "Regular bone density screening recommended; consult if fractures occur easily",
    },
    {
      name: "Memory Problems",
      symptoms: ["Forgetfulness", "Confusion", "Difficulty with familiar tasks", "Mood changes"],
      whenToConsult: "If memory loss interferes with daily life or worsens rapidly",
    },
    {
      name: "Vision Problems",
      symptoms: ["Blurred vision", "Difficulty reading", "Eye strain", "Cataracts"],
      whenToConsult: "Annual eye exams recommended; consult for sudden vision changes",
    },
  ],
};

const ageGroups = [
  { label: "Children (0-12 years)", value: "0-12" },
  { label: "Teenagers (13-25 years)", value: "13-25" },
  { label: "Adults (26-45 years)", value: "26-45" },
  { label: "Middle Age (46-60 years)", value: "46-60" },
  { label: "Seniors (60+ years)", value: "60+" },
];

export function HealthIssues() {
  const [selectedAge, setSelectedAge] = useState<string>("26-45");

  const currentIssues = healthIssuesByAge[selectedAge] || [];

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-500 to-teal-500 rounded-lg p-8 text-white">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center">
            <Activity className="w-8 h-8" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Common Health Issues</h1>
            <p className="text-emerald-100 mt-1">Age-specific health information and guidance</p>
          </div>
        </div>
      </div>

      {/* Age Group Selection */}
      <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
        <h2 className="text-xl font-semibold text-slate-800 mb-4 flex items-center gap-2">
          <Users className="w-5 h-5 text-emerald-600" />
          Select Age Group
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {ageGroups.map((group) => (
            <button
              key={group.value}
              onClick={() => setSelectedAge(group.value)}
              className={`p-4 rounded-lg border-2 transition-all text-center ${
                selectedAge === group.value
                  ? "border-emerald-500 bg-emerald-50 text-emerald-700 font-semibold"
                  : "border-slate-200 hover:border-emerald-300 text-slate-600"
              }`}
            >
              <div className="text-sm">{group.label}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Health Issues List */}
      <div className="space-y-4">
        {currentIssues.map((issue, index) => (
          <div key={index} className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
            <h3 className="text-xl font-semibold text-slate-800 mb-4">{issue.name}</h3>

            {/* Symptoms */}
            <div className="mb-4">
              <h4 className="font-semibold text-slate-700 mb-2 flex items-center gap-2">
                <Activity className="w-4 h-4 text-blue-500" />
                Common Symptoms
              </h4>
              <div className="flex flex-wrap gap-2">
                {issue.symptoms.map((symptom, idx) => (
                  <span
                    key={idx}
                    className="px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-sm border border-blue-100"
                  >
                    {symptom}
                  </span>
                ))}
              </div>
            </div>

            {/* When to Consult */}
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
              <h4 className="font-semibold text-amber-900 mb-2 flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                When to Consult a Doctor
              </h4>
              <p className="text-sm text-amber-800">{issue.whenToConsult}</p>
            </div>
          </div>
        ))}
      </div>

      {/* General Health Tips */}
      <div className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-lg p-6 border border-emerald-100">
        <h3 className="font-semibold text-slate-800 mb-3">🩺 General Health Tips</h3>
        <ul className="space-y-2 text-sm text-slate-700">
          <li>• Schedule regular health check-ups based on your age group</li>
          <li>• Maintain a balanced diet rich in fruits, vegetables, and whole grains</li>
          <li>• Stay physically active with at least 30 minutes of exercise daily</li>
          <li>• Get adequate sleep (7-9 hours for adults)</li>
          <li>• Stay hydrated by drinking plenty of water throughout the day</li>
          <li>• Manage stress through relaxation techniques and hobbies</li>
          <li>• Avoid tobacco and limit alcohol consumption</li>
          <li>• Keep up with recommended vaccinations and screenings</li>
        </ul>
      </div>

      {/* Emergency Notice */}
      <div className="bg-red-50 border-2 border-red-200 rounded-lg p-6">
        <div className="flex items-start gap-3">
          <AlertCircle className="w-6 h-6 text-red-600 flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-semibold text-red-900 mb-2">Emergency Warning Signs</h3>
            <p className="text-sm text-red-800 mb-2">
              Seek immediate medical attention if you experience:
            </p>
            <ul className="text-sm text-red-800 space-y-1">
              <li>• Chest pain or pressure</li>
              <li>• Difficulty breathing or shortness of breath</li>
              <li>• Severe bleeding or injury</li>
              <li>• Sudden severe headache or vision changes</li>
              <li>• Loss of consciousness or confusion</li>
              <li>• Signs of stroke (facial drooping, arm weakness, speech difficulty)</li>
            </ul>
            <p className="text-sm text-red-900 font-semibold mt-3">
              🚨 Call emergency services immediately (911 or local emergency number)
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
