import { createBrowserRouter } from "react-router";
import { RootLayout } from "@/app/components/RootLayout";
import { HomePage } from "@/app/pages/HomePage";
import { PregnancyCare } from "@/app/pages/PregnancyCare";
import { PillTracker } from "@/app/pages/PillTracker";
import { MentalWellness } from "@/app/pages/MentalWellness";
import { DoctorAppointment } from "@/app/pages/DoctorAppointment";
import { HealthIssues } from "@/app/pages/HealthIssues";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: RootLayout,
    children: [
      { index: true, Component: HomePage },
      { path: "pregnancy-care", Component: PregnancyCare },
      { path: "pill-tracker", Component: PillTracker },
      { path: "mental-wellness", Component: MentalWellness },
      { path: "doctor-appointment", Component: DoctorAppointment },
      { path: "health-issues", Component: HealthIssues },
    ],
  },
]);
