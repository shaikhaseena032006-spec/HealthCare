import { Outlet, Link, useLocation } from "react-router";
import { Home, Baby, Pill, Heart, Calendar, Activity } from "lucide-react";

const navigation = [
  { name: "Home", href: "/", icon: Home },
  { name: "Pregnancy Care", href: "/pregnancy-care", icon: Baby },
  { name: "Pill Tracker", href: "/pill-tracker", icon: Pill },
  { name: "Mental Wellness", href: "/mental-wellness", icon: Heart },
  { name: "Doctor Appointment", href: "/doctor-appointment", icon: Calendar },
  { name: "Health Issues", href: "/health-issues", icon: Activity },
];

export function RootLayout() {
  const location = useLocation();

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-semibold text-teal-600">HealthCare+</h1>
            <p className="text-sm text-slate-600 hidden sm:block">Your Complete Healthcare Companion</p>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="container mx-auto px-4">
          <div className="flex overflow-x-auto scrollbar-hide">
            {navigation.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.href;
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  className={`flex items-center gap-2 px-4 py-3 border-b-2 transition-colors whitespace-nowrap ${
                    isActive
                      ? "border-teal-500 text-teal-600"
                      : "border-transparent text-slate-600 hover:text-teal-600 hover:border-slate-300"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-sm font-medium">{item.name}</span>
                </Link>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-12">
        <div className="container mx-auto px-4 py-6">
          <p className="text-center text-sm text-slate-500">
            © 2026 HealthCare+. For informational purposes only. Consult a healthcare professional for medical advice.
          </p>
        </div>
      </footer>
    </div>
  );
}
